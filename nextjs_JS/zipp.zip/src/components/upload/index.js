export { default as UploadAvatar } from './UploadAvatar';
export { default as UploadMultiFile } from './UploadMultiFile';
export { default as UploadSingleFile } from './UploadSingleFile';
